package com.example.dogapi.controller;

import com.example.dogapi.model.Dog;
import com.example.dogapi.service.DogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/dogs")
public class DogController {
	@Autowired
	private DogService dogService;

	// Create a new Dog record
	@PostMapping
	public ResponseEntity<Dog> addDog(@Valid @RequestBody Dog dog) {
		Dog savedDog = dogService.addDog(dog);
		return new ResponseEntity<>(savedDog, HttpStatus.CREATED);
	}

	// Retrieve a Dog by its ID
	@GetMapping("/{id}")
	public ResponseEntity<Dog> getDog(@PathVariable String id) {
		Dog dog = dogService.getDogById(id);
		return new ResponseEntity<>(dog, HttpStatus.OK);
	}

	// Search dogs by breed (if provided) with pagination support
	@GetMapping
	public ResponseEntity<Page<Dog>> searchDogs(
			@RequestParam(required = false) String breed,
			@RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "10") int size) {

		Page<Dog> dogs = dogService.searchDogs(breed, page, size);
		return new ResponseEntity<>(dogs, HttpStatus.OK);
	}

	// Update an existing Dog
	@PutMapping("/{id}")
	public ResponseEntity<Dog> updateDog(@PathVariable String id, @Valid @RequestBody Dog dog) {
		Dog updatedDog = dogService.updateDog(id, dog);
		return new ResponseEntity<>(updatedDog, HttpStatus.OK);
	}

	// Delete a Dog by id
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteDog(@PathVariable String id) {
		dogService.deleteDog(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	
}
