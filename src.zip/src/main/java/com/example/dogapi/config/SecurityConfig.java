package com.example.dogapi.config;

import org.springframework.context.annotation.Bean;

import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.WebSecurityConfigurer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SecurityConfig  {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http

                .csrf(csrf -> csrf.disable())

                .authorizeRequests(authz -> authz
                        .antMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll()
                        .antMatchers(HttpMethod.GET, "/api/dogs/**").hasAuthority("READ")


                        .antMatchers(HttpMethod.POST, "/api/dogs/**").hasAuthority("WRITE")
                        .antMatchers(HttpMethod.PUT, "/api/dogs/**").hasAuthority("WRITE")
                        .antMatchers(HttpMethod.DELETE, "/api/dogs/**").hasAuthority("WRITE")
                        .anyRequest().authenticated()
                )


                .oauth2ResourceServer(oauth2 -> oauth2.jwt());

        return http.build();
    }

    @Bean
    public InMemoryUserDetailsManager userDetailsService() {

        UserDetails reader = User.withDefaultPasswordEncoder() // For demo purposes only!
                .username("user")
                .password("password")
                .authorities("READ")
                .build();


        UserDetails writer = User.withDefaultPasswordEncoder() // For demo purposes only!
                .username("admin")
                .password("admin")
                .authorities("READ", "WRITE")
                .build();

        return new InMemoryUserDetailsManager(reader, writer);
    }
}