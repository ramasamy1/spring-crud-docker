package com.example.dogapi.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Document(collection = "dogs")
public class Dog {

	@Id
	private String id;

	@NotEmpty(message = "Breed is required")
	private String breed;

	private String description;

	@NotEmpty(message = "Picture URL is required")
	private String pictureUrl;

	@NotNull(message = "Height is required")
	private Double height;

	@NotNull(message = "Weight is required")
	private Double weight;

	private String lifeSpan;

	// Flexible list field; additional tags can be added here
	private List<String> breedCharacteristics;

	public Dog() {
	}

	// Constructors, Getters and Setters

	public Dog(String id, String breed, String description, String pictureUrl,
			   Double height, Double weight, String lifeSpan, List<String> breedCharacteristics) {
		this.id = id;
		this.breed = breed;
		this.description = description;
		this.pictureUrl = pictureUrl;
		this.height = height;
		this.weight = weight;
		this.lifeSpan = lifeSpan;
		this.breedCharacteristics = breedCharacteristics;
	}

	// --- Getters and Setters ---
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPictureUrl() {
		return pictureUrl;
	}

	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}

	public Double getHeight() {
		return height;
	}

	public void setHeight(Double height) {
		this.height = height;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getLifeSpan() {
		return lifeSpan;
	}

	public void setLifeSpan(String lifeSpan) {
		this.lifeSpan = lifeSpan;
	}

	public List<String> getBreedCharacteristics() {
		return breedCharacteristics;
	}

	public void setBreedCharacteristics(List<String> breedCharacteristics) {
		this.breedCharacteristics = breedCharacteristics;
	}
}