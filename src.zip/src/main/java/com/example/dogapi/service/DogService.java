package com.example.dogapi.service;

import java.util.List;
import java.util.Optional;



import com.example.dogapi.exception.DogNotFoundException;
import com.example.dogapi.model.Dog;
import com.example.dogapi.repository.DogRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

@Service
public class DogService {

	private static final Logger logger = LoggerFactory.getLogger(DogService.class);

	@Autowired
	private DogRepository repository;

	public Dog addDog(Dog dog) {
		logger.info("Adding new dog: {}", dog.getBreed());
		return repository.save(dog);
	}
	@Cacheable(value = "dogs", key = "#id")
	public Dog getDogById(String id) {
		logger.info("Retrieving dog with id: {}", id);
		Optional<Dog> optionalDog = repository.findById(id);
		if (optionalDog.isPresent()) {
			return optionalDog.get();
		} else {
			throw new DogNotFoundException("Dog not found with id: " + id);
		}
	}

	@Cacheable(value = "searchResults", key = "#breed + '-' + #page + '-' + #size")
	public Page<Dog> searchDogs(String breed, int page, int size) {
		logger.info("Searching dogs with breed filter: {}, page: {}, size: {}", breed, page, size);
		List<Dog> dogs;
		if (breed != null && !breed.isEmpty()) {
			dogs = repository.findByBreedContainingIgnoreCase(breed);
		} else {
			dogs = repository.findAll();
		}
		// For simplicity, manually paginate the list.
		int start = (int) Math.min(page * size, dogs.size());
		int end = (int) Math.min(start + size, dogs.size());
		List<Dog> paginatedList = dogs.subList(start, end);

		return new PageImpl<>(paginatedList, PageRequest.of(page, size), dogs.size());
	}
	@CachePut(value = "dogs", key = "#id")
	public Dog updateDog(String id, Dog updatedDog) {
		logger.info("Updating dog with id: {}", id);
		Dog existingDog = getDogById(id);

		// Update fields
		existingDog.setBreed(updatedDog.getBreed());
		existingDog.setDescription(updatedDog.getDescription());
		existingDog.setPictureUrl(updatedDog.getPictureUrl());
		existingDog.setHeight(updatedDog.getHeight());
		existingDog.setWeight(updatedDog.getWeight());
		existingDog.setLifeSpan(updatedDog.getLifeSpan());
		existingDog.setBreedCharacteristics(updatedDog.getBreedCharacteristics());

		return repository.save(existingDog);
	}
	@CacheEvict(value = "dogs", key = "#id")
	public void deleteDog(String id) {
		logger.info("Deleting dog with id: {}", id);
		Dog existingDog = getDogById(id);
		repository.delete(existingDog);
	}
}