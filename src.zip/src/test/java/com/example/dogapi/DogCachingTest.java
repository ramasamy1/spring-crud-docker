package com.example.dogapi;

import com.example.dogapi.model.Dog;
import com.example.dogapi.repository.DogRepository;
import com.example.dogapi.service.DogService;
import org.junit.jupiter.api.Test;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@SpringBootTest
public class DogCachingTest {

    @Autowired
    private DogService dogService;

    // Use @SpyBean so you can verify how many times the repository is called.
    @Spy
    private DogRepository dogRepository;

  /*  @Test
    public void testGetDogByIdCaching() {
        // Given: a Dog object exists in the repository.
        Dog dog = new Dog("1","Labrador Retriever", "Friendly family dog.",
                "http://example.com/labrador.jpg", 24.0, 65.0, "10-12 years",
                java.util.Arrays.asList("Adaptable", "Kid-Friendly", "Easy-to-train"));
        dog.setId("123");

        // Instruct the repository to return the dog when findById is called.
        when(dogRepository.findById("123")).thenReturn(Optional.of(dog));

        // When: the service method is called twice with the same id.
        Dog result1 = dogService.getDogById("123");
        Dog result2 = dogService.getDogById("123");

        // Then: the repository's findById method should be called only once.
        verify(dogRepository, times(1)).findById("123");

        // And: the results from both calls should be equal.
        assertEquals(result1, result2);
    }*/
}