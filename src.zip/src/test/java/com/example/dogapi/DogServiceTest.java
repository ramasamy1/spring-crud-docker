package com.example.dogapi;

import com.example.dogapi.model.Dog;
import com.example.dogapi.repository.DogRepository;
import com.example.dogapi.service.DogService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@AutoConfigureMockMvc
class DogServiceTest {

    @Mock
    DogRepository dogRepository;

    @InjectMocks
    DogService dogService;

    @Test
    void testGetDogById() {
        Dog dog = new Dog();
        dog.setId("1");
        dog.setBreed("Labrador");

        Mockito.when(dogRepository.findById("1")).thenReturn(Optional.of(dog));

        Dog foundDog = dogService.getDogById("1");

        assertNotNull(foundDog);
        assertEquals("Labrador", foundDog.getBreed());
    }
}