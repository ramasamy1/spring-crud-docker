package com.example.dogapi;

import com.example.dogapi.model.Dog;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.*;


@SpringBootTest
@AutoConfigureMockMvc
class DogControllerTest {

	@Autowired
	private MockMvc mockMvc;


	/*
	@Test
	public void testGetDogNotFound() throws Exception {
		mockMvc.perform(get("/api/dogs/invalid-id"))
				.andExpect(status().isNotFound());
	}
	@Test
	public void testGetDogById() throws Exception {
		mockMvc.perform(get("/dogs/1"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.id").value(1));
	}
	@Test
	public void testAddDog() throws Exception {
		List<String> arrayList=Arrays.asList("Adaptable");
		Dog dog = new Dog("1","Bulldog", "Description", "url", 12.5, 25.0, "12 years",arrayList);
		mockMvc.perform(post("/api/dogs")
						.contentType(MediaType.APPLICATION_JSON)
						.content(new ObjectMapper().writeValueAsString(dog)))
				.andExpect(status().isCreated());
	}*/
}